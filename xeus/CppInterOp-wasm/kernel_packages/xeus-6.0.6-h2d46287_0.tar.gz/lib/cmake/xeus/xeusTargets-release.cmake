#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "xeus" for configuration "Release"
set_property(TARGET xeus APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(xeus PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libxeus.so"
  IMPORTED_NO_SONAME_RELEASE "TRUE"
  )

list(APPEND _cmake_import_check_targets xeus )
list(APPEND _cmake_import_check_files_for_xeus "${_IMPORT_PREFIX}/lib/libxeus.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
